<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       rvgud/
 * @since      1.0.0
 *
 * @package    Try_on_woocommerece
 * @subpackage Try_on_woocommerece/public/partials
 */
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
$Webcam_extension_for_eye_wear_tryon='webcam_extension_for_eye_wear_tryon/webcam_extension_for_eye_wear_tryon.php';
$Webcam_extension_for_eye_wear_tryon_intalled=false;
if(is_plugin_active( $Webcam_extension_for_eye_wear_tryon )){
    $Webcam_extension_for_eye_wear_tryon_intalled=true;
    require_once( ABSPATH . PLUGINDIR .'/webcam_extension_for_eye_wear_tryon/public/partials/webcam_extension_for_eye_wear_tryon-public-display.php' );
    $webcam=new Webcam_extension_for_eye_wear_tryon_public_display();
    
}

$Side_view_extension_for_eye_wear_tryon='side_view_extension_for_eye_wear_try_on/side_view_extension_for_eye_wear_try_on.php';
$Side_view_extension_for_eye_wear_tryon_installed=false;
if(is_plugin_active( $Side_view_extension_for_eye_wear_tryon )){
    $Side_view_extension_for_eye_wear_tryon_installed=true;
    require_once( ABSPATH . PLUGINDIR .'/side_view_extension_for_eye_wear_try_on/public/partials/side_view_extension_for_eye_wear_try_on-public-display.php' );
    $side_view=new Side_view_extension_for_eye_wear_tryon_public_display();
    
}

?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

    <script>
        var front_uploaded_flag=false;
        var side_uploaded_flag=false;
        var global_view ="Front";
        var video_streaming=false;
        var tryOnImgUrl='';
        var tryOnSideImgUrl='';
        var productid='';
        function convert_canvas(){
          var link=document.getElementById("linkimage");
          html2canvas(document.getElementById("image_download")).then(function(canvas) {
          var dt = canvas.toDataURL('image/png').replace("image/png", "image/octet-stream");
          link.href = dt;
          link.setAttribute("download","Face.png");
        });
            
      }
        $( function() {
    $( "#galssimagediv" ).draggable();
            
  } );
        
        rotate=0;
      
        
        function rotate_right(){
            rotate=rotate+1;
            document.getElementById("galssimagediv").style.webkitTransform="rotate("+rotate+"deg)";
            
}
        function rotate_left(){
             rotate=rotate-1;
            document.getElementById("galssimagediv").style.webkitTransform="rotate("+rotate+"deg)";
            
}
        function zoom_out(){
            var width= $("#galssimagediv").width();
            $("#galssimagediv").width( width - (width * 0.05)) ;
           
        }
        function zoom_in(){
            var width= $("#galssimagediv").width();
            $("#galssimagediv").width( width + (width * 0.05)) ;
            
        }
        <?php 
                                if($Side_view_extension_for_eye_wear_tryon_installed){
                                    echo $side_view->get_side_button_js($tryOnImgUrl,$tryOnSideImgUrl);
                                }?>
       
        function save_image(el){
            $(el).css("display","none");
            var download_link=$("#linkimage");
            download_link.css("display","inline-block");
            convert_canvas();
        }
        function show_save(el){
            $(el).css("display","none");
            var download_link=$("#save_btn");
            download_link.css("display","inline-block");
        }

  </script>
   
    
     <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jqueryui-touch-punch/0.2.2/jquery.ui.touch-punch.min.js"></script>

 <div class="container">
  <!-- Trigger the modal with a button -->
     
   


  <!-- Modal -->
  <div class="modal fade" id="TryOnModal" role="dialog" style="z-index: 10000000;">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content try_on_popup">
       <div class="modal-header" style="padding-top: 5px;
    padding-left: 5px;padding-bottom: 0px;">
            <div class="row" style="margin-bottom:0px;">
                <div class="col-md-12 col-lg-12  col-xs-12  col-sm-12">
                            <label for="imageLoader">
                                <span  class=" picture glyphicon glyphicon-picture" data-toggle="tooltip" data-placement="top" title="Upload Your Image">   
                        <input type="file" id="imageLoader" name="imageLoader" accept="image/*;capture=camera"/>
                                    </span>
                         </label>
                            
               
                            <?php 
                                if($Webcam_extension_for_eye_wear_tryon_intalled){
                                    echo $webcam->get_camera_button();
                                }
                            ?>
               
                        <span class="picture glyphicon glyphicon-repeat" data-toggle="tooltip" data-placement="top" title="Rotate Clockwise" onclick="rotate_right()">
                        </span>
                           
                    <span class="picture glyphicon glyphicon-repeat rotate-gly" onclick="rotate_left()" data-toggle="tooltip" data-placement="top" title="Rotate Anti Clock Wise">
                        </span> 
                    <span class="picture  glyphicon glyphicon-zoom-in" ontouchstart="zoom_in()" onclick="zoom_in()" data-toggle="tooltip" data-placement="top" title="Enlarge Glass size">
                                 </span>
                            <span class="picture glyphicon glyphicon-zoom-out" ontouchstart="zoom_out()" onclick="zoom_out()" data-toggle="tooltip" data-placement="top" title="Shrink Glass size">
                        </span>
                    
                       <!-- <a id="linkimage" onclick="this.css('display','none');"><span  id="download_btn"  style="display:none" class="picture glyphicon glyphicon-download"> </span></a>-->
                       
                    
                    
            <button type="button" class="close" data-dismiss="modal">&times;</button>
                 </div>   </div>
          </div>
        <div class="modal-body" id="modal_body">
            <div class="row" style="margin-bottom:0px;">
                <div class="col-lg-12 col-xs-12 col-sm-12">
                    <div class="row" style="margin-bottom:0px;">
                        <div class="col-lg-12  col-md-12 col-xs-12 col-sm-12">
                            <div id="image_download" class="row" >
                                <div id="galssimagediv"  >
                            <img  id="galssimage" src=""  class="img-responsive img-thumbnail fixed_images"  >
                        </div>
                        <img style="width: 100%;"  src="<?php echo plugins_url().'/try_on_woocommerece/public/images/man_face.jpg' ?>" id="imageCanvas" class="img-responsive img-thumbnail fixed_images" alt="Cinque Terre">
                        <img    id="front_uploaded"  style="display:none;width: 100%;" class="img-thumbnail fixed_images" />
                        <img     id="side_uploaded"  style="display:none;width: 100%;" class="img-thumbnail fixed_images"/>
                       </div>
                                
                               
          <button id="save_btn" style="display:none;" class=".btn btn-success savendownload"  onclick="save_image(this);"> Save</button>
          <a href="#" id="linkimage" onclick="show_save(this);" style="display:none;" class="btn btn-info savendownload" role="button">Download</a>
       
                        <?php
                        if($Webcam_extension_for_eye_wear_tryon_intalled)
                            echo $webcam->get_video_div();
                    ?>
                            <button id="capture_btn" style="display:none;" class=".btn btn-success savendownload"  onclick="snapshot();"> Capture</button> 
                             <?php 
                                if($Side_view_extension_for_eye_wear_tryon_installed){
                                    echo $side_view->get_side_button();
                                }
                            ?>
                        </div>
                        
                       
                         
                    </div>
                    
                </div>
                
                
            </div>
        </div>
            <script>
            
            var imageLoader = document.getElementById('imageLoader');
            imageLoader.addEventListener('change', handleImage, false);
            var canvas1 = $("#imageCanvas");
            var front_uploaded = $("#front_uploaded");
            var side_uploaded = $("#side_uploaded");
            var view=$("#side_btn").text();
                function handleImage(e){
                    <?php
                        if($Webcam_extension_for_eye_wear_tryon_intalled)
                            echo 'var video = $("#video");video.css("display","none");';
                    ?>
                    video_streaming=false;
                    var reader = new FileReader();
                    reader.onload = function(event){        
                        var img_uploaded_front = new Image();
                        img_uploaded_front.onload = function(){
                            canvas1.css("display","none");
                            if(global_view=="Front"){
                                front_uploaded_flag=true;
                                side_uploaded.css("display","none");
                                front_uploaded.css("display","block");
                                front_uploaded.attr("src",img_uploaded_front.src);
                            }
                            else{
                                side_uploaded_flag=true;
                                front_uploaded.css("display","none");
                                side_uploaded.css("display","block");
                                side_uploaded.attr("src",img_uploaded_front.src);
                            }
                            convert_canvas();
                            var download_link=$("#save_btn");
                            download_link.css("display","inline-block");
                        }
                    img_uploaded_front.src = event.target.result;
                    convert_canvas();
                    }
                    reader.readAsDataURL(e.target.files[0]);     
                }
                
               
  

              
            </script>
               
         <?php if($Webcam_extension_for_eye_wear_tryon_intalled)
          echo $webcam->get_camera_button_js();
          ?>

        <div class="modal-footer">
            <?php echo "<a class='btn btn-info' id='addtocartlink' href=''><span class='glyphicons glyphicons-shoping-cart'></span>Add to cart</a>";?> 
          
        </div>
      </div>
      
    </div>
  </div>
  
</div>

