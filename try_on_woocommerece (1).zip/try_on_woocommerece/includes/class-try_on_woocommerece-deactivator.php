<?php

/**
 * Fired during plugin deactivation
 *
 * @link       rvgud/
 * @since      1.0.0
 *
 * @package    Try_on_woocommerece
 * @subpackage Try_on_woocommerece/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Try_on_woocommerece
 * @subpackage Try_on_woocommerece/includes
 * @author     rvgud <rvgud@gmail.com>
 */
class Try_on_woocommerece_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
