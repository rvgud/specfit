<?php

/**
 * Fired during plugin activation
 *
 * @link       rvgud/
 * @since      1.0.0
 *
 * @package    Try_on_woocommerece
 * @subpackage Try_on_woocommerece/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Try_on_woocommerece
 * @subpackage Try_on_woocommerece/includes
 * @author     rvgud <rvgud@gmail.com>
 */
class Try_on_woocommerece_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
