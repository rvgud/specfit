<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       rvgud/
 * @since      1.0.0
 *
 * @package    Try_on_woocommerece
 * @subpackage Try_on_woocommerece/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<html>
<body>
    <div>
    Virtual try on Plugin.
    </div>
    </body>
</html>